package com.example.FlightAware.config;

import org.springframework.context.annotation.Configuration;

@Configuration
//@EnableWebSecurity
//@Deprecated

public class SecurityConfiguration {

}
//public class SecurityConfiguration extends WebSecurityConfigurerAdapter {
//
//
//    @Override
//    protected void configure(HttpSecurity http) throws Exception {
//        http.authorizeRequests()
//                .antMatchers("/").permitAll()
//                .antMatchers("/Register").permitAll()
//                .antMatchers("/Login").permitAll()
//                .antMatchers("/home").permitAll();
//    }
//}
