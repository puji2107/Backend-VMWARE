# FlightAware
This application will provide details about flights. Users can list places, view flight prices, route wise flights, country details, city details. 
